<template>
  <settings></settings>
</template>
<script>
import Settings from '@/components/Settings'
export default {
  name: 'settings-page',
  components: {
    Settings
  }
}
</script>
