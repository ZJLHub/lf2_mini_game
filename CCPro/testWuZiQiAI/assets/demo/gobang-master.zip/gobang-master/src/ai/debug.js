var debug = {};
export default debug;
